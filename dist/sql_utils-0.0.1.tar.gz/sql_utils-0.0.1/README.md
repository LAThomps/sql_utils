# sql_utils

[![PyPI - Version](https://img.shields.io/pypi/v/sql-utils.svg)](https://pypi.org/project/sql-utils)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/sql-utils.svg)](https://pypi.org/project/sql-utils)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install sql_utils
```

## License

`sql_utils` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
